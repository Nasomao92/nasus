const feedback = document.querySelector(".feedback");
const closePopup = document.querySelector(".close-popup");
const popupWindow = document.querySelector(".popup-window");

feedback.addEventListener("click",
function (evt) {
	evt.preventDefault();
	popupWindow.classList.add("popup-window--opened");
}
);

closePopup.addEventListener("click",
function (evt) {
	evt.preventDefault();
	popupWindow.classList.remove("popup-window--opened");
}
);
